import os
import flask
from flask import request, jsonify
from flask_cors import CORS
from ASM2MC import parse
from stageFunctions import ProcessingUnit
from cnv2mc import conv2mc

app = flask.Flask(__name__)
CORS(app)
app.config["DEBUG"] = False

proc = None

@app.route('/api/download/')
def dump():
    with open('new_code.mc','r') as f:
        s = f.read()
    return "<pre>"+s+"</pre>"

@app.route('/api/machine-code/', methods=['POST'])
def api():
    global proc
    try:
        Original, Basic, Machine, _ = parse(request.form['code'])
        conv2mc(request.form['code'])
        proc = ProcessingUnit('new_code.mc')
        return jsonify({
                'error':False,
                'original':Original,
                'basic':Basic,
                'machine':Machine,
                'data':proc.MEM,
                'register':proc.RegisterFile
            })
    except Exception as e:
        return jsonify(
            {
                'error':True,
                'errormsg':str(e)
            }
        )

@app.route('/api/step/', methods=['POST'])
def step():
    global proc
    proc.fetch()
    proc.decode()
    proc.execute()
    proc.memory_access()
    proc.write_back()
    return jsonify({
                'PC':proc.PC,
                'data':proc.MEM,
                'register':proc.RegisterFile
            })

@app.route('/api/run/', methods=['POST'])
def run():
    global proc
    num = -1
    breakpoints = [int(x) for x in request.form['breakpoints'].split()]
    while True:
        if(proc.PC//4 in breakpoints and num!=-1):
            num+=1
            break
        num+=1
        proc.fetch()
        if(proc.IR == 0):
            break
        proc.decode()
        proc.execute()
        proc.memory_access()
        proc.write_back()
    return jsonify({
                'num':num,
                'PC':proc.PC,
                'data':proc.MEM,
                'register':proc.RegisterFile
            })



@app.route('/api/prev/', methods=['POST'])
def prev():
    global proc
    proc = ProcessingUnit('new_code.mc')
    num = int(request.form['num'])
    for _ in range(num):
        proc.fetch()
        if(proc.IR == 0):
            break
        proc.decode()
        proc.execute()
        proc.memory_access()
        proc.write_back()
    return jsonify({
                'PC':proc.PC,
                'data':proc.MEM,
                'register':proc.RegisterFile
            })



app.run()

