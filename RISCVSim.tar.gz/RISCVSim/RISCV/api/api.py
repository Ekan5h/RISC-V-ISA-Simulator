import os
import flask
from flask import request, jsonify
from flask_cors import CORS
from ASM2MC import parse
from stageFunctions import ProcessingUnit
from cnv2mc import conv2mc
from runScript import pipeline

app = flask.Flask(__name__)
CORS(app)
app.config["DEBUG"] = False

proc = None
pipl = None
basic = None

@app.route('/api/download/')
def dump():
    with open('new_code.mc','r') as f:
        s = f.read()
    return "<pre>"+s+"</pre>"

@app.route('/api/machine-code/', methods=['POST'])
def api():
    global proc
    try:
        Original, Basic, Machine, _ = parse(request.form['code'])
        conv2mc(request.form['code'])
        proc = ProcessingUnit('new_code.mc')
        return jsonify({
                'error':False,
                'original':Original,
                'basic':Basic,
                'machine':Machine,
                'data':proc.MEM,
                'register':proc.RegisterFile
            })
    except Exception as e:
        return jsonify(
            {
                'error':True,
                'errormsg':str(e)
            }
        )

@app.route('/api/step/', methods=['POST'])
def step():
    global proc
    proc.fetch()
    proc.decode()
    proc.execute()
    proc.memory_access()
    proc.write_back()
    return jsonify({
                'PC':proc.PC,
                'data':proc.MEM,
                'register':proc.RegisterFile
            })

@app.route('/api/run/', methods=['POST'])
def run():
    global proc
    num = -1
    breakpoints = [int(x) for x in request.form['breakpoints'].split()]
    while True:
        if(proc.PC//4 in breakpoints and num!=-1):
            num+=1
            break
        num+=1
        proc.fetch()
        if(proc.IR == 0):
            break
        proc.decode()
        proc.execute()
        proc.memory_access()
        proc.write_back()
    return jsonify({
                'num':num,
                'PC':proc.PC,
                'data':proc.MEM,
                'register':proc.RegisterFile
            })



@app.route('/api/prev/', methods=['POST'])
def prev():
    global proc
    proc = ProcessingUnit('new_code.mc')
    num = int(request.form['num'])
    for _ in range(num):
        proc.fetch()
        if(proc.IR == 0):
            break
        proc.decode()
        proc.execute()
        proc.memory_access()
        proc.write_back()
    return jsonify({
                'PC':proc.PC,
                'data':proc.MEM,
                'register':proc.RegisterFile
            })

@app.route('/api/pipeline-setup/', methods=['POST'])
def pipset():
    global pipl
    global basic
    del pipl
    try:
        _, basic, _, _ = parse(request.form['code'])
        conv2mc(request.form['code'])
        pipl = pipeline()
        return jsonify({
                    'error':False,
                })
    except Exception as e:
        pipl = None
        return jsonify(
            {
                'error':True,
                'errormsg':str(e)
            }
        )

@app.route('/api/pipeline-basic/', methods=['POST'])
def basicCode():
    return jsonify(
        {
            'basic':basic
        }
    )

@app.route('/api/pipeline-reset/', methods=['POST'])
def pipReset():
    global pipl
    del pipl
    pipl = pipeline()
    return ""


@app.route('/api/pipeline-step/', methods=['POST'])
def piplineStep():
    states, paths, data_hazard, control_hazard = pipl.cycle()
    predicted_outcome = -1
    taken = -1
    if states[0].iscontrol:
        predicted_outcome = 1 if states[0].predicted_outcome else 0
    if states[1].iscontrol:
        taken = 0 if control_hazard else 1
    PCs = [-1 if x.unstarted else x.PC for x in states]
    return jsonify(
        {
            'predict': predicted_outcome,
            'taken': taken,
            'pc': PCs,
            'fpaths': paths,
            'dhazard': data_hazard,
            'chazard': control_hazard
        }
    )

app.run()

