from stageFunctions3 import ProcessingUnit, State, BTB
from hazard import HDU
import sys
class pipeline:
	def __init__(self):
		self.enable_prediction = True
		self.proc=ProcessingUnit('new_code.mc',enable_prediction=True)
		self.in_states=[State() for i in range(5)]
		self.out_states=[]
		self.print_Final_register=False
		self.print_Final_Mem=False
		self.master_PC=0
		self.master_clock=0
		self.stalling_enabled=False #Knob 2
		self.print_regFile_for_each_ins=False #Knob 3
		self.control_hazard = False
		self.control_hazard_PC = 0
		self.control_change = False
		self.control_change_PC = 0
		self.print_pipline_registers=False #Knob4
		self.print_pipline_registers_for_specific=[False,-1] #Knob5
		self.hdu = HDU()
		self.btb = BTB()
		self.count_branch_hazards=0
		self.count_data_hazards=0
		self.count_branch_hazards_stalls=0
		self.count_data_hazards_stalls=0

	def cycle(self):
		return_states = []
		if self.stalling_enabled:
			data_hazard=self.hdu.check_data_hazard_stalling(self.in_states)
			backup_states=self.in_states
			self.in_states=[(idx,val) for idx,val in enumerate(self.in_states)]
			reversed_states=self.in_states[::-1]
			for idx,state in reversed_states:
				if idx==0:
					self.control_change, self.control_change_PC, tempstate = self.proc.fetch(state, self.btb)
					self.out_states.append(tempstate)
				if idx==1:
					self.control_hazard, self.control_hazard_PC, tempstate = self.proc.decode(state, self.btb)
					self.out_states.append(tempstate)
				if idx==2:
					self.out_states.append(self.proc.execute(state))
				if idx==3:
					self.out_states.append(self.proc.memory_access(state))
				if idx==4:
					self.proc.write_back(state)
			self.out_states=self.out_states[::-1]
			if self.stalling_enabled:
				if self.out_states[0].IR!=0 and (data_hazard[0]==False):
					self.master_PC +=4
			else:
				if self.out_states[0].IR!=0:
					self.master_PC+=4
			if(self.control_change and data_hazard[0]==False):
				self.master_PC = self.control_change_PC
			if(self.control_hazard and data_hazard[0]==False):
				self.count_branch_hazards+=1
				self.count_branch_hazards_stalls+=1
				self.master_PC = self.control_hazard_PC
				self.out_states[0] = State(0)
			elif (self.control_hazard and data_hazard[0] and self.enable_prediction):
				self.btb.changeState(self.in_states[1].PC)
				
			if data_hazard[0]:
				self.count_data_hazards+=1
				self.count_data_hazards_stalls+=1
				self.out_states=[backup_states[1],State(0)]+self.out_states[2:]
		# For data forwarding
		else:
			isHazard = False
			doStall = False
			stallWhere = 3
			forwarding_paths = set()
			for i in reversed(range(5)):
				if i==0:
					self.control_change, self.control_change_PC, tempstate = self.proc.fetch(self.in_states[0], self.btb)
					self.out_states.append(tempstate)
				if i==1:
					self.control_hazard, self.control_hazard_PC, tempstate = self.proc.decode(self.in_states[1], self.btb)
					self.out_states.append(tempstate)
				if i==2:
					self.out_states.append(self.proc.execute(self.in_states[2]))
				if i==3:
					self.out_states.append(self.proc.memory_access(self.in_states[3]))
				if i==4:
					self.proc.write_back(self.in_states[4])
					hazards = self.hdu.check_data_hazard(self.in_states)
					self.in_states[3] = hazards[2][3]
					forwarding_paths.update(hazards[4])
				if i<4:
					self.in_states[i] = self.out_states[-1]
					hazards = self.hdu.check_data_hazard(self.in_states)
					self.in_states = hazards[2]
					isHazard = isHazard | hazards[0]
					doStall = doStall | hazards[1]
					stallWhere = min(stallWhere, hazards[3])
					forwarding_paths.update(hazards[4])
			if isHazard:
				self.count_data_hazards+=len(forwarding_paths)
			self.out_states=self.out_states[::-1]
			if self.out_states[0].IR!=0 and (doStall==False):
				self.master_PC +=4

			if(self.control_change and doStall==False):
				self.master_PC = self.control_change_PC

			if(self.control_hazard and doStall==False):
				self.count_branch_hazards+=1
				self.count_branch_hazards_stalls+=1
				self.master_PC = self.control_hazard_PC
				self.out_states[0] = State(0)
			elif (self.control_hazard and doStall and self.enable_prediction):
				self.btb.changeState(self.in_states[1].PC)

			if doStall:
				# Stall at execute
				self.count_data_hazards_stalls+=1
				if stallWhere==1:
					self.out_states = [self.in_states[1], self.in_states[2], State()] + [self.out_states[3]]
				# Stall at decode
				else:
					self.out_states = [self.in_states[1], State()] + [self.out_states[2], self.out_states[3]]
		self.master_clock +=1
		# if self.out_states[0].IR==0 and self.out_states[1].IR==0 and self.out_states[2].IR==0 and self.out_states[3].IR==0 and progress=="Completed":
		# 	break
		return_states = self.out_states + [self.in_states[-1]]
		self.in_states=[State(self.master_PC)]
		self.in_states=self.in_states+self.out_states
		self.out_states=[]
		print(self.btb.table)
		return return_states, list(forwarding_paths), data_hazard[0] if self.stalling_enabled else isHazard, self.control_hazard and data_hazard[0]==False if self.stalling_enabled else self.control_hazard and doStall==False
