#!/usr/bin/env python3
import os
from multiprocessing import Process

def startHTTP():
    import http.server
    import socketserver
    PORT = 3000
    os.chdir("RISCV/static/")
    Handler = http.server.SimpleHTTPRequestHandler
    httpd = socketserver.TCPServer(("", PORT), Handler)
    print("Serving at port", PORT)
    httpd.serve_forever()

def server():
    os.chdir("RISCV/api/")
    print("Starting simulation server...")
    os.system("python3 api.py")
    
x = Process(target = startHTTP)
x.start()
y = Process(target = server)
y.start()
os.system("google-chrome --app=http://localhost:3000/ --user-data-dir=RISCV/chrome-files")
os.system("kill -9 $(lsof -t -i:3000)")
os.system("kill -9 $(lsof -t -i:5000)")
print("--------------------------------------------------------------------------------")
print("Program terminated successfully!")
